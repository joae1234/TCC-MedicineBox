import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_browser_client.dart';

class MqttService {
  late MqttBrowserClient client;
  bool isConnected = false;
  final String brokerUrl = 'wss://mqtt.eclipseprojects.io/mqtt';
  final int brokerPort = 443;
  final String topicStatus = 'remedio/estado';
  final String topicCommand = 'comando/led';

  Future<void> connect() async {
    client = MqttBrowserClient(brokerUrl, 'flutter_${DateTime.now().millisecondsSinceEpoch}')
      ..port = brokerPort
      ..keepAlivePeriod = 30
      ..onConnected = _onConnected
      ..onDisconnected = _onDisconnected
      ..logging(on: false);

    try {
      print('🔄 Tentando conectar ao MQTT...');
      await client.connect();
    } catch (e) {
      print('❌ Erro ao conectar: $e');
      isConnected = false;
    }
  }

  void _onConnected() {
    print('✅ Conectado ao broker MQTT');
    isConnected = true;
  }

  void _onDisconnected() {
    print('⚠️ Desconectado do broker');
    isConnected = false;
    _tryReconnect(); // nova função
  }

  Future<void> _tryReconnect() async {
    const retryDelay = Duration(seconds: 5);
    while (!isConnected) {
      print('🔁 Tentando reconectar...');
      await Future.delayed(retryDelay);
      try {
        await connect();
      } catch (_) {
        print('⚠️ Reconexão falhou. Tentando novamente...');
      }
    }
  }

  void publishCommand(String cmd, String topic) {
    if (!isConnected) {
      print('❌ Não conectado. Comando não enviado.');
      return;
    }

    final builder = MqttClientPayloadBuilder()..addString(cmd);
    client.publishMessage(topic, MqttQos.atLeastOnce, builder.payload!);
    print('📤 Publicado: "$cmd" em "$topic"');
  }

  void sendCommand(String command) => publishCommand(command, topicCommand);

  void disconnect() {
    if (isConnected) {
      client.disconnect();
      print('🔌 Desconectado manualmente');
    }
  }
}
