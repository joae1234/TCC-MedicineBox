package com.example.medicine_box

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
